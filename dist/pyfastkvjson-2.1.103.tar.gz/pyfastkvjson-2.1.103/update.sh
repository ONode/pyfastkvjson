#!/bin/sh
. ./n

testup
GIT_LOC=https://github.com/ONode/pyfastkvjson
pub_repo
gitpush